# Rent-a-Car Management System
Access Credentials

- Username: admin
- Password: 123